/**
 * CS2030S PE2 Question 1
 * AY20/21 Semester 2
 *
 * @author A0000000X
 */
